import { Queue } from "bullmq";
import IORedis from "ioredis";

const connection = new IORedis(process.env.REDIS_URL || "redis://localhost:6379", {
  maxRetriesPerRequest: null,
});

// Queue for renewal reminder emails
export const emailQueue = new Queue("renewal-reminders", { connection });

export { connection };