import { Worker, Job } from "bullmq";
import { connection } from "./queue";
import { transporter } from "../config/mailer";

export interface RenewalJobData {
  email: string;
  name: string;
  expiryDate: string;
  planName: string;
}

export function startEmailWorker() {
  const worker = new Worker<RenewalJobData>(
    "renewal-reminders",
    async (job: Job<RenewalJobData>) => {
      const { email, name, expiryDate, planName } = job.data;

      console.log(`[Worker] Sending renewal reminder to ${email}`);

      await transporter.sendMail({
        from: process.env.MAIL_FROM || "billing@saas.local",
        to: email,
        subject: "Your subscription is expiring soon",
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto;">
            <h2 style="color: #5469d4;">Subscription Renewal Reminder</h2>
            <p>Hi ${name || "there"},</p>
            <p>Your <strong>${planName}</strong> subscription is expiring on <strong>${expiryDate}</strong>.</p>
            <p>Please renew your subscription to continue enjoying uninterrupted access.</p>
            <a href="http://localhost:3000" style="display:inline-block; margin-top:16px; padding:12px 24px; background:#5469d4; color:#fff; border-radius:6px; text-decoration:none;">
              Renew Now
            </a>
            <p style="margin-top:24px; color:#999; font-size:12px;">
              If you have already renewed, please ignore this email.
            </p>
          </div>
        `,
      });

      console.log(`[Worker] Renewal reminder sent to ${email}`);
    },
    { connection }
  );

  worker.on("completed", (job) => {
    console.log(`[Worker] Job ${job.id} completed`);
  });

  worker.on("failed", (job, err) => {
    console.error(`[Worker] Job ${job?.id} failed:`, err.message);
  });

  console.log("[Worker] Email worker started, listening for jobs...");
  return worker;
}