import { Queue } from "bullmq";
import { emailQueue } from "./queue";
import prisma from "../config/prisma";

// Runs every day at 9:00 AM - finds subscriptions expiring in 3 days
export async function checkExpiringSubscriptions() {
  console.log("[Cron] Checking for expiring subscriptions...");

  const now = new Date();
  const threeDaysLater = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);

  try {
    // Find active subscriptions expiring within the next 3 days
    // that have not had a reminder sent yet
    const expiringSubs = await prisma.subscription.findMany({
      where: {
        status: "active",
        currentPeriodEnd: {
          gte: now,
          lte: threeDaysLater,
        },
        reminderSentAt: null,  // only send once
      },
      include: {
        user: true,
      },
    });

    console.log(`[Cron] Found ${expiringSubs.length} subscription(s) expiring soon`);

    for (const sub of expiringSubs) {
      const expiryDate = sub.currentPeriodEnd.toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "long",
        year: "numeric",
      });

      // Add job to BullMQ queue
      await emailQueue.add(
        "renewal-reminder",
        {
          email: sub.user.email,
          name: sub.user.name || sub.user.email,
          expiryDate,
          planName: "Pro Plan",
        },
        {
          attempts: 3,
          backoff: { type: "exponential", delay: 5000 },
        }
      );

      // Mark reminder as sent so we don't send again
      await prisma.subscription.update({
        where: { id: sub.id },
        data: { reminderSentAt: new Date() },
      });

      console.log(`[Cron] Queued renewal reminder for ${sub.user.email}`);
    }
  } catch (err: any) {
    console.error("[Cron] Error checking expiring subscriptions:", err.message);
  }
}

// Start the cron scheduler
export function startRenewalCron() {
  // Run immediately on startup (for testing)
  checkExpiringSubscriptions();

  // Then run every 24 hours
  const interval = setInterval(checkExpiringSubscriptions, 24 * 60 * 60 * 1000);

  console.log("[Cron] Renewal cron started - runs every 24 hours");
  return interval;
}